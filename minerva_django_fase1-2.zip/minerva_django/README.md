# Minerva Aeroespacial Institucional — versão Django

Esta é a conversão do projeto original (Next.js/React/TypeScript) para **Python + Django**.

## O que já foi migrado (Fase 1 e 2)

- Estrutura do projeto Django (`minerva_project`) com o app `core`
- Layout base (header/footer), reaproveitado em todas as páginas
- Site institucional completo:
  - Início (`/`)
  - Equipe (`/equipe/`)
  - Projetos (`/projetos/`)
  - Sistemas (`/sistemas/`)
  - Publicações (`/publicacoes/`)
  - Contato (`/contato/`) — com formulário **real**, que grava no banco de dados
- Autenticação real (`django.contrib.auth`) nas telas de login:
  - Login da área restrita: `/login/`
  - Login administrativo: `/admin-login/`
- Painel administrativo pronto do Django em `/admin/` (gerencie notícias e mensagens de contato)

## Como rodar o projeto

1. Crie e ative um ambiente virtual (recomendado):
   ```bash
   python3 -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   ```

2. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```

3. Rode as migrações (cria o banco de dados SQLite):
   ```bash
   python manage.py migrate
   ```

4. Crie um usuário para testar o login:
   ```bash
   python manage.py createsuperuser
   ```
   > Já deixei um usuário de teste pronto no banco enviado: **usuário `admin`, senha `admin123`** (é só um exemplo — troque depois).

5. Rode o servidor:
   ```bash
   python manage.py runserver
   ```

6. Acesse no navegador:
   - Site: http://127.0.0.1:8000/
   - Painel admin do Django: http://127.0.0.1:8000/admin/

## Estrutura de pastas

```
minerva_django/
├── manage.py
├── requirements.txt
├── db.sqlite3              # banco de dados (SQLite) já com o usuário admin de teste
├── minerva_project/         # configurações do projeto (settings.py, urls.py)
├── core/                    # app com as views, models, forms e urls
│   ├── models.py            # Noticia, MensagemContato
│   ├── forms.py             # ContatoForm
│   ├── views.py             # todas as páginas
│   ├── urls.py
│   └── admin.py
├── templates/
│   ├── base.html            # layout (equivalente ao layout.tsx)
│   ├── includes/
│   │   ├── header.html
│   │   └── footer.html
│   └── core/
│       ├── home.html
│       ├── equipe.html
│       ├── projetos.html
│       ├── sistemas.html
│       ├── publicacoes.html
│       ├── contato.html
│       ├── login.html
│       └── admin_login.html
└── static/                  # arquivos estáticos do projeto
```

## Decisões técnicas importantes

- **Estilo (CSS):** o projeto original usa Tailwind CSS com um processo de build via Node.js.
  Para reproduzir o mesmo visual **sem exigir Node.js**, os templates usam o **Tailwind via CDN**
  (`<script src="https://cdn.tailwindcss.com">` em `base.html`). Isso funciona bem para desenvolvimento
  e para você continuar aprendendo Django sem se preocupar com build de front-end. Se um dia quiser productionizar
  com Tailwind "de verdade" (compilado), dá pra migrar depois — não é urgente.
- **Ícones:** trocamos `lucide-react` pela versão web do Lucide via CDN (`<i data-lucide="...">`), que renderiza os
  mesmos ícones.
- **Menu mobile:** no React ele abre/fecha com `useState`; aqui usei a tag HTML `<details>/<summary>`, que faz o
  mesmo efeito sem precisar escrever JavaScript.
- **Autenticação:** os logins fake (`admin/aerospace123` e `admin/admin123` fixos no código) foram substituídos
  pelo sistema de usuários real do Django. Crie os usuários que quiser com `createsuperuser` ou pelo `/admin/`.
- **Dados fixos (mock):** as listas de equipe, projetos, sistemas e publicações ainda estão escritas diretamente em
  `core/views.py` (assim como estavam em `.tsx`), pra manter a Fase 2 simples. O modelo `Noticia` já é um exemplo de
  como isso vai virar tabela de banco de dados nas próximas fases.

## Próximas fases (ainda não feitas)

- **Fase 3:** revisar e reforçar a autenticação (grupos/permissões diferenciando área restrita de área admin)
- **Fase 4:** criar os models `Quotation` (Cotação) e `Purchase` (Compra), e mover Equipe/Projetos/Sistemas/Publicações
  para o banco de dados também, com telas de cadastro
- **Fase 5:** sistema de cotação, aprovação e compras (`/restrito/cotacao/...`) — a parte mais trabalhosa
- **Fase 6:** dashboard administrativo (`/admin/dashboard`)
- **Fase 7:** upload de arquivos e modal de pagamento

Quando quiser continuar, é só pedir a próxima fase.
